// Copyright (c) 2018 JachinShen(jachinshen@foxmail.com)
// 
// This software is released under the MIT License.
// https://opensource.org/licenses/MIT

// split Bayer Matrix of the raw data to speed up
#define HACKING_OFF  0
#define HACKING_ON   1

#define BAYER_HACKING HACKING_OFF